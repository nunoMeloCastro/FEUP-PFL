:- include('utils.pl').
:- include('menu.pl').

play:-
    clear,
    display_logo,
    display_main_menu_logo,
    display_main_menu.

